# QA Report — Batch 1 (No Images)

## basic
- Words: ~939
- Image placeholder: N/A (per user)
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## alcohol-dilution
- Words: ~914
- Image placeholder: N/A (per user)
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## baking
- Words: ~899
- Image placeholder: N/A (per user)
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## area
- Words: ~867
- Image placeholder: N/A (per user)
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## abacus
- Words: ~1398
- Image placeholder: N/A (per user)
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## age
- Words: ~736
- Image placeholder: N/A (per user)
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## aquarium-volume
- Words: ~790
- Image placeholder: N/A (per user)
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## age-on-mars
- Words: ~735
- Image placeholder: N/A (per user)
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## bodyfat
- Words: ~774
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## binary-converter
- Words: ~723
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## bmr
- Words: ~801
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## capacitor
- Words: ~716
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## braille-translator
- Words: ~684
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## bmi
- Words: ~749
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## budget
- Words: ~711
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## calorie
- Words: ~735
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## credit-card-payoff
- Words: ~786
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## car-lease
- Words: ~901
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## coffee-ratio
- Words: ~728
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## cat-age
- Words: ~742
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## compound-interest
- Words: ~721
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## currency-converter
- Words: ~700
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## concrete
- Words: ~781
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## car-loan
- Words: ~757
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## date
- Words: ~832
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## depreciation
- Words: ~818
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## dog-age
- Words: ~722
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## electrical
- Words: ~727
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## equation-solver
- Words: ~805
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## ev-range
- Words: ~783
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## fitness
- Words: ~760
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## fraction
- Words: ~677
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## fuel-cost
- Words: ~784
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## golf-balls-boeing-747
- Words: ~756
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## gpa
- Words: ~717
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## graphing
- Words: ~687
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## heartrate
- Words: ~722
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## interest
- Words: ~666
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## investment
- Words: ~724
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## loan
- Words: ~710
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## love-calculator
- Words: ~604
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## matrix
- Words: ~708
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## molecular-weight
- Words: ~666
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## morse-code
- Words: ~658
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## mortgage
- Words: ~790
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## mpg
- Words: ~663
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## npv-irr
- Words: ~724
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## ohms-law
- Words: ~682
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## paint
- Words: ~847
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## password-generator
- Words: ~745
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## patio
- Words: ~774
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## percentage
- Words: ~720
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## ph
- Words: ~845
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## prime
- Words: ~678
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## protein
- Words: ~741
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## ratio
- Words: ~663
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## recipe-converter
- Words: ~893
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## refinance
- Words: ~810
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## resistor
- Words: ~748
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## retirement
- Words: ~776
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## roi
- Words: ~709
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## roman-numerals
- Words: ~666
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## roofing
- Words: ~760
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## salary
- Words: ~723
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## scientific
- Words: ~839
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## seed-spacing
- Words: ~860
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## significant-figures
- Words: ~789
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## sleep
- Words: ~807
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## solar-panel-savings
- Words: ~801
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## space-weight
- Words: ~812
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## speed
- Words: ~745
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## stairs
- Words: ~904
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## stoichiometry
- Words: ~906
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## subnet
- Words: ~764
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## tax
- Words: ~781
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## tile
- Words: ~794
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## tip
- Words: ~737
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## tire-size
- Words: ~767
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## unit-converter
- Words: ~762
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## volume
- Words: ~782
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —

## water
- Words: ~797
- H1 present: yes
- JSON-LD blocks: yes
- Related links section: yes
- FAQ: yes
- How-to section: yes
- Notes: —
