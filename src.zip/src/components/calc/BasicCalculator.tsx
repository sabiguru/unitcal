'use client';

import { useState } from 'react';
import KeypadGrid from '@/components/ui/KeypadGrid';

export default function BasicCalculator() {
  const [display, setDisplay] = useState('0');
  const [expression, setExpression] = useState('');
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForNewValue, setWaitingForNewValue] = useState(false);

  const inputNumber = (num: string) => {
    if (waitingForNewValue) {
      setDisplay(num);
      if (operation && previousValue !== null) {
        const operatorSymbol = operation === '*' ? '×' : operation === '/' ? '÷' : operation;
        setExpression(`${previousValue} ${operatorSymbol} ${num}`);
      } else {
        setExpression(num);
      }
      setWaitingForNewValue(false);
    } else {
      const newDisplay = display === '0' ? num : display + num;
      setDisplay(newDisplay);
      if (operation && previousValue !== null) {
        const operatorSymbol = operation === '*' ? '×' : operation === '/' ? '÷' : operation;
        setExpression(`${previousValue} ${operatorSymbol} ${newDisplay}`);
      } else {
        setExpression(newDisplay);
      }
    }
  };

  const inputOperation = (nextOperation: string) => {
    const inputValue = parseFloat(display);
    const operatorSymbol = nextOperation === '*' ? '×' : nextOperation === '/' ? '÷' : nextOperation;

    if (previousValue === null) {
      setPreviousValue(inputValue);
      setExpression(`${inputValue} ${operatorSymbol} `);
    } else if (operation && !waitingForNewValue) {
      const currentValue = previousValue || 0;
      const result = calculate(currentValue, inputValue, operation);
      setDisplay(String(result));
      setPreviousValue(result);
      setExpression(`${result} ${operatorSymbol} `);
    } else {
      setExpression(expression.replace(/[+\-×÷] $/, `${operatorSymbol} `));
    }

    setWaitingForNewValue(true);
    setOperation(nextOperation);
  };

  const calculate = (firstValue: number, secondValue: number, operation: string) => {
    switch (operation) {
      case '+': return firstValue + secondValue;
      case '-': return firstValue - secondValue;
      case '*': return firstValue * secondValue;
      case '/': return firstValue / secondValue;
      default: return secondValue;
    }
  };

  const handleEqual = () => {
    const inputValue = parseFloat(display);
    if (previousValue !== null && operation) {
      const result = calculate(previousValue, inputValue, operation);
      const finalExpression = expression + ' = ' + result;
      setExpression(finalExpression);
      setDisplay(String(result));
      setPreviousValue(null);
      setOperation(null);
      setWaitingForNewValue(true);
    }
  };

  const clear = () => {
    setDisplay('0');
    setExpression('');
    setPreviousValue(null);
    setOperation(null);
    setWaitingForNewValue(false);
  };

  const clearEntry = () => {
    setDisplay('0');
  };

  const ButtonStyle = {
    number: 'bg-white hover:bg-gray-50 text-slate-700 border border-gray-200 hover:border-slate-300 shadow-sm hover:shadow-md transition-all duration-150 text-sm sm:text-base md:text-lg font-medium py-2 sm:py-3 px-1 sm:px-2',
    operator: 'bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white shadow-sm hover:shadow-md transition-all duration-150 text-sm sm:text-base md:text-lg font-medium py-2 sm:py-3 px-1 sm:px-2',
    equals: 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white shadow-sm hover:shadow-md transition-all duration-150 text-sm sm:text-base md:text-lg font-medium py-2 sm:py-3 px-1 sm:px-2',
    clear: 'bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white shadow-sm hover:shadow-md transition-all duration-150 text-sm sm:text-base md:text-lg font-medium py-2 sm:py-3 px-1 sm:px-2'
  };

  const keys = [
    // Row 1
    { label: 'C', onClick: clear, className: ButtonStyle.clear },
    { label: 'CE', onClick: clearEntry, className: ButtonStyle.clear },
    { label: '⌫', onClick: () => setDisplay(display.slice(0, -1) || '0'), className: ButtonStyle.operator },
    { label: '÷', onClick: () => inputOperation('/'), className: ButtonStyle.operator },
    
    // Row 2
    { label: '7', onClick: () => inputNumber('7'), className: ButtonStyle.number },
    { label: '8', onClick: () => inputNumber('8'), className: ButtonStyle.number },
    { label: '9', onClick: () => inputNumber('9'), className: ButtonStyle.number },
    { label: '×', onClick: () => inputOperation('*'), className: ButtonStyle.operator },
    
    // Row 3
    { label: '4', onClick: () => inputNumber('4'), className: ButtonStyle.number },
    { label: '5', onClick: () => inputNumber('5'), className: ButtonStyle.number },
    { label: '6', onClick: () => inputNumber('6'), className: ButtonStyle.number },
    { label: '−', onClick: () => inputOperation('-'), className: ButtonStyle.operator },
    
    // Row 4
    { label: '1', onClick: () => inputNumber('1'), className: ButtonStyle.number },
    { label: '2', onClick: () => inputNumber('2'), className: ButtonStyle.number },
    { label: '3', onClick: () => inputNumber('3'), className: ButtonStyle.number },
    { label: '+', onClick: () => inputOperation('+'), className: ButtonStyle.operator },
    
    // Row 5
    { label: '0', onClick: () => inputNumber('0'), className: ButtonStyle.number, span: 2 },
    { label: '.', onClick: () => inputNumber('.'), className: ButtonStyle.number },
    { label: '=', onClick: handleEqual, className: ButtonStyle.equals }
  ];

  return (
    <div className="mb-8 calculator-container">
      <div className="flex items-center mb-6 calculator-header">
        <div className="w-12 h-12 sm:w-16 sm:h-16 bg-gradient-to-r from-slate-600 to-slate-700 rounded-xl flex items-center justify-center mr-3 sm:mr-4 flex-shrink-0">
          <span className="text-amber-200 text-lg sm:text-2xl">🧮</span>
        </div>
        <div className="flex-1">
          <h1 className="text-2xl sm:text-3xl font-bold text-gray-900 mb-2">Basic Calculator</h1>
          <p className="text-sm sm:text-base text-gray-600">Perform standard arithmetic operations with a simple interface</p>
        </div>
      </div>
      
      {/* Display */}
      <div className="mb-6">
        <div className="bg-gray-900 rounded-xl p-3 sm:p-4 text-white calculator-display">
          <div className="text-xs sm:text-sm text-gray-400 mb-2 h-4 sm:h-6 overflow-hidden">
            {expression || ' '}
          </div>
          <div className="text-xl sm:text-3xl font-mono text-right overflow-hidden">
            {display}
          </div>
        </div>
      </div>

      {/* Buttons */}
      <KeypadGrid keys={keys} cols={4} />
    </div>
  );
}