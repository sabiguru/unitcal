'use client';

import { useState } from 'react';
import KeypadGrid from '@/components/ui/KeypadGrid';

export default function ScientificCalculator() {
  const [display, setDisplay] = useState('0');
  const [expression, setExpression] = useState('');
  const [previousValue, setPreviousValue] = useState<number | null>(null);
  const [operation, setOperation] = useState<string | null>(null);
  const [waitingForNewValue, setWaitingForNewValue] = useState(false);
  const [memory, setMemory] = useState(0);
  const [isInverse, setIsInverse] = useState(false);
  const [isHyperbolic, setIsHyperbolic] = useState(false);
  const [angleMode, setAngleMode] = useState<'DEG' | 'RAD' | 'GRAD'>('DEG');

  const inputNumber = (num: string) => {
    if (waitingForNewValue) {
      setDisplay(num);
      if (operation && previousValue !== null) {
        const operatorSymbol = operation === '*' ? '×' : operation === '/' ? '÷' : operation;
        setExpression(`${previousValue} ${operatorSymbol} ${num}`);
      } else {
        setExpression(num);
      }
      setWaitingForNewValue(false);
    } else {
      const newDisplay = display === '0' ? num : display + num;
      setDisplay(newDisplay);
      if (operation && previousValue !== null) {
        const operatorSymbol = operation === '*' ? '×' : operation === '/' ? '÷' : operation;
        setExpression(`${previousValue} ${operatorSymbol} ${newDisplay}`);
      } else {
        setExpression(newDisplay);
      }
    }
  };

  const inputOperation = (nextOperation: string) => {
    const inputValue = parseFloat(display);
    const operatorSymbol = nextOperation === '*' ? '×' : nextOperation === '/' ? '÷' : nextOperation;

    if (previousValue === null) {
      setPreviousValue(inputValue);
      setExpression(`${inputValue} ${operatorSymbol} `);
    } else if (operation && !waitingForNewValue) {
      const currentValue = previousValue || 0;
      const result = calculate(currentValue, inputValue, operation);
      setDisplay(String(result));
      setPreviousValue(result);
      setExpression(`${result} ${operatorSymbol} `);
    } else {
      setExpression(expression.replace(/[+\-×÷^] $/, `${operatorSymbol} `));
    }

    setWaitingForNewValue(true);
    setOperation(nextOperation);
  };

  const calculate = (firstValue: number, secondValue: number, operation: string) => {
    switch (operation) {
      case '+': return firstValue + secondValue;
      case '-': return firstValue - secondValue;
      case '*': return firstValue * secondValue;
      case '/': return firstValue / secondValue;
      case '^': return Math.pow(firstValue, secondValue);
      case 'yx': return Math.pow(firstValue, secondValue);
      case 'mod': return firstValue % secondValue;
      default: return secondValue;
    }
  };

  const handleEqual = () => {
    const inputValue = parseFloat(display);
    if (previousValue !== null && operation) {
      const result = calculate(previousValue, inputValue, operation);
      const finalExpression = expression + ' = ' + result;
      setExpression(finalExpression);
      setDisplay(String(result));
      setPreviousValue(null);
      setOperation(null);
      setWaitingForNewValue(true);
    }
  };

  const clear = () => {
    setDisplay('0');
    setExpression('');
    setPreviousValue(null);
    setOperation(null);
    setWaitingForNewValue(false);
  };

  const handleScientificFunction = (func: string) => {
    const value = parseFloat(display);
    let result: number;
    let funcExpression = '';
    
    const toRadians = (val: number) => {
      switch (angleMode) {
        case 'DEG': return val * Math.PI / 180;
        case 'GRAD': return val * Math.PI / 200;
        default: return val;
      }
    };
    
    switch (func) {
      case 'sin': 
        result = isHyperbolic ? Math.sinh(value) : Math.sin(isInverse ? Math.asin(value) : toRadians(value));
        funcExpression = `${isHyperbolic ? 'sinh' : isInverse ? 'asin' : 'sin'}(${value}) = ${result}`;
        break;
      case 'cos': 
        result = isHyperbolic ? Math.cosh(value) : Math.cos(isInverse ? Math.acos(value) : toRadians(value));
        funcExpression = `${isHyperbolic ? 'cosh' : isInverse ? 'acos' : 'cos'}(${value}) = ${result}`;
        break;
      case 'tan': 
        result = isHyperbolic ? Math.tanh(value) : Math.tan(isInverse ? Math.atan(value) : toRadians(value));
        funcExpression = `${isHyperbolic ? 'tanh' : isInverse ? 'atan' : 'tan'}(${value}) = ${result}`;
        break;
      case 'log': result = Math.log10(value); funcExpression = `log(${value}) = ${result}`; break;
      case 'ln': result = Math.log(value); funcExpression = `ln(${value}) = ${result}`; break;
      case '10^x': result = Math.pow(10, value); funcExpression = `10^${value} = ${result}`; break;
      case 'e^x': result = Math.pow(Math.E, value); funcExpression = `e^${value} = ${result}`; break;
      case 'x²': result = value * value; funcExpression = `${value}² = ${result}`; break;
      case 'x³': result = value * value * value; funcExpression = `${value}³ = ${result}`; break;
      case '√': result = Math.sqrt(value); funcExpression = `√${value} = ${result}`; break;
      case '1/x': result = 1 / value; funcExpression = `1/${value} = ${result}`; break;
      case 'x!': result = factorial(value); funcExpression = `${value}! = ${result}`; break;
      case 'π': result = Math.PI; funcExpression = `π = ${result}`; break;
      case 'e': result = Math.E; funcExpression = `e = ${result}`; break;
      case '±': result = -value; funcExpression = `-(${value}) = ${result}`; break;
      case 'abs': result = Math.abs(value); funcExpression = `|${value}| = ${result}`; break;
      default: result = value; funcExpression = `${value}`;
    }
    
    setExpression(funcExpression);
    setDisplay(String(result));
    setWaitingForNewValue(true);
    setIsInverse(false);
    setIsHyperbolic(false);
  };

  const factorial = (n: number): number => {
    if (n <= 1) return 1;
    if (n > 170) return Infinity;
    return n * factorial(n - 1);
  };

  const handleMemory = (action: string) => {
    const value = parseFloat(display);
    switch (action) {
      case 'MC': setMemory(0); break;
      case 'MR': setDisplay(String(memory)); setWaitingForNewValue(true); break;
      case 'M+': setMemory(memory + value); break;
      case 'M-': setMemory(memory - value); break;
      case 'MS': setMemory(value); break;
    }
  };

  const ButtonStyle = {
    number: 'bg-white hover:bg-gray-50 text-slate-700 border border-gray-200 hover:border-slate-300 shadow-sm hover:shadow-md transition-all duration-150 text-sm sm:text-base md:text-lg font-medium py-2 sm:py-3 px-1 sm:px-2',
    operator: 'bg-gradient-to-r from-slate-600 to-slate-700 hover:from-slate-700 hover:to-slate-800 text-amber-100 shadow-sm hover:shadow-md transition-all duration-150 text-sm sm:text-base md:text-lg font-medium py-2 sm:py-3 px-1 sm:px-2',
    scientific: 'bg-gradient-to-r from-amber-600 to-amber-700 hover:from-amber-700 hover:to-amber-800 text-white shadow-sm hover:shadow-md transition-all duration-150 text-xs sm:text-sm font-medium py-1 sm:py-2 px-1',
    equals: 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white shadow-sm hover:shadow-md transition-all duration-150 text-sm sm:text-base md:text-lg font-medium py-2 sm:py-3 px-1 sm:px-2',
    clear: 'bg-gradient-to-r from-red-500 to-red-600 hover:from-red-600 hover:to-red-700 text-white shadow-sm hover:shadow-md transition-all duration-150 text-xs sm:text-sm font-medium py-1 sm:py-2 px-1',
    memory: 'bg-gradient-to-r from-slate-500 to-slate-600 hover:from-slate-600 hover:to-slate-700 text-amber-100 shadow-sm hover:shadow-md transition-all duration-150 text-xs sm:text-sm font-medium py-1 sm:py-2 px-1',
    mode: (isInverse || isHyperbolic) ? 'bg-gradient-to-r from-amber-500 to-amber-600 hover:from-amber-600 hover:to-amber-700 text-white shadow-sm hover:shadow-md transition-all duration-150 text-xs sm:text-sm font-medium py-1 sm:py-2 px-1' : 'bg-gradient-to-r from-slate-500 to-slate-600 hover:from-slate-600 hover:to-slate-700 text-amber-100 shadow-sm hover:shadow-md transition-all duration-150 text-xs sm:text-sm font-medium py-1 sm:py-2 px-1'
  };

  // Key definitions for different sections
  const modeKeys = [
    { label: angleMode, onClick: () => setAngleMode(angleMode === 'DEG' ? 'RAD' : angleMode === 'RAD' ? 'GRAD' : 'DEG'), className: ButtonStyle.mode },
    { label: 'INV', onClick: () => setIsInverse(!isInverse), className: isInverse ? ButtonStyle.equals : ButtonStyle.mode },
    { label: 'HYP', onClick: () => setIsHyperbolic(!isHyperbolic), className: isHyperbolic ? ButtonStyle.equals : ButtonStyle.mode },
    { label: 'MC', onClick: () => handleMemory('MC'), className: ButtonStyle.memory },
    { label: 'MR', onClick: () => handleMemory('MR'), className: ButtonStyle.memory },
    { label: 'MS', onClick: () => handleMemory('MS'), className: ButtonStyle.memory }
  ];

  const scientificRow1Keys = [
    { label: 'sin', onClick: () => handleScientificFunction('sin'), className: ButtonStyle.scientific },
    { label: 'cos', onClick: () => handleScientificFunction('cos'), className: ButtonStyle.scientific },
    { label: 'tan', onClick: () => handleScientificFunction('tan'), className: ButtonStyle.scientific },
    { label: 'log', onClick: () => handleScientificFunction('log'), className: ButtonStyle.scientific },
    { label: 'ln', onClick: () => handleScientificFunction('ln'), className: ButtonStyle.scientific },
    { label: 'x!', onClick: () => handleScientificFunction('x!'), className: ButtonStyle.scientific }
  ];

  const scientificRow2Keys = [
    { label: '10^x', onClick: () => handleScientificFunction('10^x'), className: ButtonStyle.scientific },
    { label: 'e^x', onClick: () => handleScientificFunction('e^x'), className: ButtonStyle.scientific },
    { label: '√', onClick: () => handleScientificFunction('√'), className: ButtonStyle.scientific },
    { label: 'x²', onClick: () => handleScientificFunction('x²'), className: ButtonStyle.scientific },
    { label: '1/x', onClick: () => handleScientificFunction('1/x'), className: ButtonStyle.scientific },
    { label: 'x^y', onClick: () => inputOperation('^'), className: ButtonStyle.scientific }
  ];

  const constantsKeys = [
    { label: 'π', onClick: () => handleScientificFunction('π'), className: ButtonStyle.scientific },
    { label: 'e', onClick: () => handleScientificFunction('e'), className: ButtonStyle.scientific },
    { label: '|x|', onClick: () => handleScientificFunction('abs'), className: ButtonStyle.scientific },
    { label: '±', onClick: () => handleScientificFunction('±'), className: ButtonStyle.operator },
    { label: 'AC', onClick: clear, className: ButtonStyle.clear },
    { label: 'DEL', onClick: () => setDisplay(display.slice(0, -1) || '0'), className: ButtonStyle.clear }
  ];

  const numberKeys = [
    { label: '7', onClick: () => inputNumber('7'), className: ButtonStyle.number },
    { label: '8', onClick: () => inputNumber('8'), className: ButtonStyle.number },
    { label: '9', onClick: () => inputNumber('9'), className: ButtonStyle.number },
    { label: '÷', onClick: () => inputOperation('/'), className: ButtonStyle.operator },
    
    { label: '4', onClick: () => inputNumber('4'), className: ButtonStyle.number },
    { label: '5', onClick: () => inputNumber('5'), className: ButtonStyle.number },
    { label: '6', onClick: () => inputNumber('6'), className: ButtonStyle.number },
    { label: '×', onClick: () => inputOperation('*'), className: ButtonStyle.operator },
    
    { label: '1', onClick: () => inputNumber('1'), className: ButtonStyle.number },
    { label: '2', onClick: () => inputNumber('2'), className: ButtonStyle.number },
    { label: '3', onClick: () => inputNumber('3'), className: ButtonStyle.number },
    { label: '−', onClick: () => inputOperation('-'), className: ButtonStyle.operator },
    
    { label: '0', onClick: () => inputNumber('0'), className: ButtonStyle.number },
    { label: '.', onClick: () => inputNumber('.'), className: ButtonStyle.number },
    { label: '+', onClick: () => inputOperation('+'), className: ButtonStyle.operator },
    { label: '=', onClick: handleEqual, className: ButtonStyle.equals }
  ];

  return (
    <div className="mb-8">
      <div className="flex items-center mb-6">
        <div className="w-16 h-16 bg-gradient-to-r from-purple-500 to-indigo-600 rounded-xl flex items-center justify-center mr-4 flex-shrink-0">
          <span className="text-white text-2xl">🔬</span>
        </div>
        <div className="flex-1">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Scientific Calculator</h1>
          <p className="text-gray-600">Advanced mathematical functions including trigonometry and logarithms</p>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-lg border border-gray-200 p-4 sm:p-6">
        {/* Display */}
        <div className="mb-6">
          <div className="bg-gray-900 rounded-xl p-3 sm:p-4 text-white">
            <div className="text-xs sm:text-sm text-gray-400 mb-2 h-4 sm:h-6 overflow-hidden">
              {expression || ' '}
            </div>
            <div className="text-xl sm:text-3xl font-mono text-right mb-2 overflow-hidden">
              {display}
            </div>
            <div className="flex justify-between text-xs sm:text-sm text-gray-400">
              <span>Mode: {angleMode}</span>
              <span>Memory: {memory !== 0 ? memory : 'Empty'}</span>
            </div>
          </div>
        </div>

        {/* Mode and Memory Row */}
        <div className="mb-2">
          <KeypadGrid keys={modeKeys} cols={6} />
        </div>

        {/* Scientific Functions Row 1 */}
        <div className="mb-2">
          <KeypadGrid keys={scientificRow1Keys} cols={6} />
        </div>

        {/* Scientific Functions Row 2 */}
        <div className="mb-2">
          <KeypadGrid keys={scientificRow2Keys} cols={6} />
        </div>

        {/* Constants and Clear Row */}
        <div className="mb-2">
          <KeypadGrid keys={constantsKeys} cols={6} />
        </div>

        {/* Main Calculator Grid */}
        <KeypadGrid keys={numberKeys} cols={4} />
      </div>
    </div>
  );
}