import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Providers } from "./providers";
import Footer from "@/components/Footer";

// Debug logging for production
if (typeof window === 'undefined') {
  // Server-side error logging
  process.on('unhandledRejection', (reason, promise) => {
    console.error('🚨 Unhandled Rejection at:', promise, 'reason:', reason);
  });

  process.on('uncaughtException', (error) => {
    console.error('🚨 Uncaught Exception:', error);
  });
}

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  metadataBase: new URL('https://calcfort.com'),
  title: "CalcFort - Free Online Calculators & Tools",
  description: "Trusted source for free online calculators and conversion tools. Mathematics, finance, health, engineering, and more. Fast, accurate, and reliable.",
  keywords: ["calculator", "online calculator", "unit converter", "math calculator", "financial calculator", "conversion tool", "calcfort"],
  authors: [{ name: "CalcFort" }],
  creator: "CalcFort",
  publisher: "CalcFort",
  robots: "index, follow",
  openGraph: {
    type: "website",
    locale: "en_US",
    url: "https://calcfort.com",
    siteName: "CalcFort",
    title: "CalcFort - Free Online Calculators & Tools",
    description: "Your trusted source for free online calculators and conversion tools. Mathematics, finance, health, engineering, and more.",
    images: [
      {
        url: "/og-image.png",
        width: 1200,
        height: 630,
        alt: "CalcFort - Your Source for Online Calculator Tools"
      }
    ]
  },
  twitter: {
    card: "summary_large_image",
    title: "CalcFort - Free Online Calculators & Tools",
    description: "Your trusted source for free online calculators and conversion tools. Mathematics, finance, health, engineering, and more.",
    images: ["/og-image.png"]
  },
  alternates: {
    canonical: "https://calcfort.com"
  }
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en">
      <head>
        <link rel="icon" href="/favicon.ico" sizes="32x32" />
        <link rel="icon" href="/favicon.svg" type="image/svg+xml" />
        <link rel="apple-touch-icon" href="/apple-touch-icon.png" />
        <link rel="manifest" href="/site.webmanifest" />
        
        {/* Seobility Verification */}
        <meta name="seobility" content="eeb290f1902ff1f4679f69365f3ac07c" />
        
        {/* Ezoic Privacy Scripts - must be loaded first */}
        <script src="https://cmp.gatekeeperconsent.com/min.js" data-cfasync="false"></script>
        <script src="https://the.gatekeeperconsent.com/cmp.min.js" data-cfasync="false"></script>
        
        {/* Ezoic Header Script */}
        <script async src="//www.ezojs.com/ezoic/sa.min.js"></script>
        <script dangerouslySetInnerHTML={{
          __html: `
            window.ezstandalone = window.ezstandalone || {};
            ezstandalone.cmd = ezstandalone.cmd || [];
          `
        }}></script>
      </head>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased`}
      >
        <Providers>
          {children}
          <Footer />
        </Providers>
      </body>
    </html>
  );
}
