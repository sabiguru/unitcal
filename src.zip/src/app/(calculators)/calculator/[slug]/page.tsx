import { notFound } from 'next/navigation';
import { calculators, bySlug } from '@/data/calculators';
import { seoBySlug } from '@/data/seoBySlug';
import dynamic from 'next/dynamic';
import Breadcrumbs from '@/components/Breadcrumbs';
import { generateCalculatorBreadcrumbs } from '@/lib/breadcrumbs';
import EzoicAd from '@/components/ads/EzoicAd';
import { EZOIC_PLACEMENTS } from '@/config/ezoicPlacements';

// Optimized dynamic import for MDX files - single chunk
const loadMDX = (mdxFile: string) => {
  return dynamic(() => import(`@/content/calculators/${mdxFile}`), {
    loading: () => <div className="animate-pulse bg-gray-200 h-24 rounded"></div>
  });
};

// Static map for known MDX files
const mdxMap: Record<string, any> = {
  'basic.mdx': loadMDX('basic.mdx'),
  'compound-interest.mdx': loadMDX('compound-interest.mdx'),
  'loan.mdx': loadMDX('loan.mdx'),
  'retirement.mdx': loadMDX('retirement.mdx'),
  'area.mdx': loadMDX('area.mdx'),
  'volume.mdx': loadMDX('volume.mdx'),
  'interest.mdx': loadMDX('interest.mdx'),
  'salary.mdx': loadMDX('salary.mdx'),
  'tax.mdx': loadMDX('tax.mdx'),
  'scientific.mdx': loadMDX('scientific.mdx'),
  'password-generator.mdx': loadMDX('password-generator.mdx'),
  'percentage.mdx': loadMDX('percentage.mdx'),
  'binary-converter.mdx': loadMDX('binary-converter.mdx'),
  'abacus.mdx': loadMDX('abacus.mdx'),
  'soroban-abacus.mdx': loadMDX('soroban-abacus.mdx'),
  'suanpan-abacus.mdx': loadMDX('suanpan-abacus.mdx'),
  'western-abacus.mdx': loadMDX('western-abacus.mdx'),
  'age-on-mars.mdx': loadMDX('age-on-mars.mdx'),
  'age.mdx': loadMDX('age.mdx'),
  'alcohol-dilution.mdx': loadMDX('alcohol-dilution.mdx'),
  'braille-translator.mdx': loadMDX('braille-translator.mdx'),
  'budget.mdx': loadMDX('budget.mdx'),
  'calorie.mdx': loadMDX('calorie.mdx'),
  'capacitor.mdx': loadMDX('capacitor.mdx'),
  'car-lease.mdx': loadMDX('car-lease.mdx'),
  'mortgage.mdx': loadMDX('mortgage.mdx'),
  'npv-irr.mdx': loadMDX('npv-irr.mdx'),
  'electrical.mdx': loadMDX('electrical.mdx'),
  'equation-solver.mdx': loadMDX('equation-solver.mdx'),
  'bmi.mdx': loadMDX('bmi.mdx'),
  'significant-figures.mdx': loadMDX('significant-figures.mdx'),
  'space-weight.mdx': loadMDX('space-weight.mdx'),
  'speed.mdx': loadMDX('speed.mdx'),
  'tip.mdx': loadMDX('tip.mdx'),
  'solar-panel-savings.mdx': loadMDX('solar-panel-savings.mdx'),
  'water.mdx': loadMDX('water.mdx'),
  'tile.mdx': loadMDX('tile.mdx'),
  'stoichiometry.mdx': loadMDX('stoichiometry.mdx'),
  'tire-size.mdx': loadMDX('tire-size.mdx'),
  'subnet.mdx': loadMDX('subnet.mdx'),
  'seed-spacing.mdx': loadMDX('seed-spacing.mdx'),
  'unit-converter.mdx': loadMDX('unit-converter.mdx'),
  'roofing.mdx': loadMDX('roofing.mdx'),
  'sleep.mdx': loadMDX('sleep.mdx'),
  'stairs.mdx': loadMDX('stairs.mdx'),
  // Additional MDX files for calculators previously without blogs
  'aquarium-volume.mdx': loadMDX('aquarium-volume.mdx'),
  'baking.mdx': loadMDX('baking.mdx'),
  'bmr.mdx': loadMDX('bmr.mdx'),
  'bodyfat.mdx': loadMDX('bodyfat.mdx'),
  'car-loan.mdx': loadMDX('car-loan.mdx'),
  'cat-age.mdx': loadMDX('cat-age.mdx'),
  'coffee-ratio.mdx': loadMDX('coffee-ratio.mdx'),
  'concrete.mdx': loadMDX('concrete.mdx'),
  'credit-card-payoff.mdx': loadMDX('credit-card-payoff.mdx'),
  'currency-converter.mdx': loadMDX('currency-converter.mdx'),
  'date.mdx': loadMDX('date.mdx'),
  'depreciation.mdx': loadMDX('depreciation.mdx'),
  'dog-age.mdx': loadMDX('dog-age.mdx'),
  'ev-range.mdx': loadMDX('ev-range.mdx'),
  'fitness.mdx': loadMDX('fitness.mdx'),
  'fraction.mdx': loadMDX('fraction.mdx'),
  'fuel-cost.mdx': loadMDX('fuel-cost.mdx'),
  'golf-balls-boeing-747.mdx': loadMDX('golf-balls-boeing-747.mdx'),
  'gpa.mdx': loadMDX('gpa.mdx'),
  'graphing.mdx': loadMDX('graphing.mdx'),
  'heartrate.mdx': loadMDX('heartrate.mdx'),
  'investment.mdx': loadMDX('investment.mdx'),
  'love-calculator.mdx': loadMDX('love-calculator.mdx'),
  'matrix.mdx': loadMDX('matrix.mdx'),
  'molecular-weight.mdx': loadMDX('molecular-weight.mdx'),
  'morse-code.mdx': loadMDX('morse-code.mdx'),
  'mpg.mdx': loadMDX('mpg.mdx'),
  'ohms-law.mdx': loadMDX('ohms-law.mdx'),
  'paint.mdx': loadMDX('paint.mdx'),
  'patio.mdx': loadMDX('patio.mdx'),
  'ph.mdx': loadMDX('ph.mdx'),
  'prime.mdx': loadMDX('prime.mdx'),
  'protein.mdx': loadMDX('protein.mdx'),
  'ratio.mdx': loadMDX('ratio.mdx'),
  'recipe-converter.mdx': loadMDX('recipe-converter.mdx'),
  'refinance.mdx': loadMDX('refinance.mdx'),
  'resistor.mdx': loadMDX('resistor.mdx'),
  'roi.mdx': loadMDX('roi.mdx'),
  'roman-numerals.mdx': loadMDX('roman-numerals.mdx'),
  // New calculators
  'energy-usage.mdx': loadMDX('energy-usage.mdx'),
  'carbon-footprint.mdx': loadMDX('carbon-footprint.mdx'),
  'home-energy-audit.mdx': loadMDX('home-energy-audit.mdx'),
  'time.mdx': loadMDX('time.mdx'),
  'timezone-converter.mdx': loadMDX('timezone-converter.mdx'),
  'countdown-timer.mdx': loadMDX('countdown-timer.mdx')
};

export function generateStaticParams() {
  return calculators.map((c) => ({ slug: c.slug }));
}

export async function generateMetadata({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const meta = bySlug[slug];
  const seoData = seoBySlug[slug];
  
  if (!meta) return {};
  
  return {
    title: seoData?.metaTitle || `${meta.title} | Calculator Fort`,
    description: seoData?.metaDescription || meta.description,
    keywords: seoData ? [
      seoData.primaryKeyword,
      ...seoData.variants,
      ...seoData.longTails
    ].join(', ') : undefined,
    robots: {
      index: true,
      follow: true,
      googleBot: {
        index: true,
        follow: true,
        'max-video-preview': -1,
        'max-image-preview': 'large',
        'max-snippet': -1,
      },
    },
    alternates: {
      canonical: `https://calcfort.com/calculator/${slug}`,
    },
  };
}

export default async function CalculatorPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const meta = bySlug[slug];
  const seoData = seoBySlug[slug];
  
  if (!meta) return notFound();

  const Calc = meta.component;
  const BlogComponent = meta.mdx ? mdxMap[meta.mdx] : null;
  const breadcrumbs = generateCalculatorBreadcrumbs(meta.title, meta.category);

  return (
    <>
      {/* JSON-LD Structured Data */}
      {seoData?.webAppSchema && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(seoData.webAppSchema)
          }}
        />
      )}
      {seoData?.faqSchema && (
        <script
          type="application/ld+json"
          dangerouslySetInnerHTML={{
            __html: JSON.stringify(seoData.faqSchema)
          }}
        />
      )}
      
      <Breadcrumbs items={breadcrumbs} />
      <div className="bg-white rounded-none sm:rounded-xl shadow-lg border-0 sm:border border-gray-200 overflow-hidden mb-8">
        <div className="p-3 sm:p-6">
          <Calc />
        </div>
      </div>

      {/* Advertisement between calculator and content */}
      <div className="mb-8">
        <EzoicAd placementId={EZOIC_PLACEMENTS.CALCULATOR_CONTENT} className="text-center" />
      </div>

      {BlogComponent && (
        <div className="bg-white rounded-xl shadow-md border border-gray-200 p-6">
          <article className="mdx-content text-gray-800 leading-relaxed">
            <BlogComponent />
          </article>
        </div>
      )}
    </>
  );
}